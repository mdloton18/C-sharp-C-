﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodCourtManagementSystem
{
    public partial class SalesmanForm : Form
    {
        private LoginForm F1 { set; get; }
        private DataAccess Da { get; set; }
        public SalesmanForm()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.FoodInfo();
        }
        public SalesmanForm(LoginForm f1):this()
        {
            //InitializeComponent();
            this.F1 = f1;
        }

        private void SalesmanForm_FormClosed(object sender, FormClosedEventArgs e)
        {

            MessageBox.Show("Closing App");
            Application.Exit();
        }
        private void FoodInfo(string sql="select * from FoodInfo")
        {
            var ds = this.Da.ExecuteQuery(sql);
            this.lblLebon.Text = ds.Tables[0].Rows[0][1].ToString();
            this.lblLebonPrice.Text = ds.Tables[0].Rows[0][2].ToString();
            this.lblPasta.Text = ds.Tables[0].Rows[1][1].ToString();
            this.lblPastaPrice.Text = ds.Tables[0].Rows[1][2].ToString();
            this.lblIceCreame.Text = ds.Tables[0].Rows[2][1].ToString();
            this.lblIceCreamePrice.Text = ds.Tables[0].Rows[2][2].ToString();
            this.lblFrices.Text = ds.Tables[0].Rows[3][1].ToString();
            this.lblFricePrice.Text = ds.Tables[0].Rows[3][2].ToString();
            this.lblBurger.Text = ds.Tables[0].Rows[4][1].ToString();
            this.lblBurgerPrice.Text = ds.Tables[0].Rows[4][2].ToString();
            this.lblChikenPot.Text = ds.Tables[0].Rows[5][1].ToString();
            this.lblChikenPotPrice.Text = ds.Tables[0].Rows[5][2].ToString();
            this.lblBread.Text = ds.Tables[0].Rows[6][1].ToString();
            this.lblBreadPrice.Text = ds.Tables[0].Rows[6][2].ToString();

        }
        private void ClearQuantity()
        {
            this.cmbLebonQuantity.Text = "0";
            this.cmbPastaQuantity.Text = "0";
            this.cmbIceCreameQuantity.Text = "0";
            this.cmbFricesQuantity.Text = "0";
            this.cmbBurgerQuantity.Text = "0";
            this.cmbChikenQuantity.Text = "0";
            this.cmbBreadQuantity.Text = "0";
            this.lblBillAmount.Text = "";
        }

        private void btnBill_Click(object sender, EventArgs e)
        {
            double totalBill;
            totalBill = (Convert.ToDouble(this.cmbLebonQuantity.Text)) * (Convert.ToDouble(this.lblLebonPrice.Text)) + (Convert.ToDouble(this.cmbPastaQuantity.Text)) * (Convert.ToDouble(this.lblPastaPrice.Text))
                + (Convert.ToDouble(this.cmbIceCreameQuantity.Text)) * (Convert.ToDouble(this.lblIceCreamePrice.Text)) + (Convert.ToDouble(this.cmbFricesQuantity.Text)) * (Convert.ToDouble(this.lblFricePrice.Text)) + 
                (Convert.ToDouble(this.cmbBurgerQuantity.Text)) * (Convert.ToDouble(this.lblBurgerPrice.Text))
                + (Convert.ToDouble(this.cmbChikenQuantity.Text)) * (Convert.ToDouble(this.lblChikenPotPrice.Text)) + (Convert.ToDouble(this.cmbBreadQuantity.Text)) * (Convert.ToDouble(this.lblBreadPrice.Text));

            //MessageBox.Show("Total bill is "+total.ToString()+" Tk");
           /// 
            this.lblBillAmount.Text = totalBill.ToString()+" Tk";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearQuantity();
        }

        private void btnShowFoodInfo_Click(object sender, EventArgs e)
        {
            this.PopulateGridViewFood();
        }
         private void PopulateGridViewFood(string sql = "select * from FoodInfo;")
        {
            var ds = this.Da.ExecuteQuery(sql);

            this.dgvFoodInfo.AutoGenerateColumns = false;
            this.dgvFoodInfo.DataSource = ds.Tables[0];
        }

         private void btnFoodSearch_Click(object sender, EventArgs e)
         {

             try
             {
                 string sql = "select * from FoodInfo where FoodName = '" + this.txtSearch.Text + "';";
                 this.PopulateGridViewFood(sql);
             }
             catch (Exception exc)
             {
                 MessageBox.Show("An error has occured: " + exc.Message);
             }
         }

         private void btnClearFoodInfo_Click(object sender, EventArgs e)
         {
             this.txtSearch.Clear();
         }

         private void btnLogOut_Click(object sender, EventArgs e)
         {
             this.Hide();
             MessageBox.Show("Logout Complete");
             this.F1.Show();
         }

         private void btnSearchSalesman_Click(object sender, EventArgs e)
         {
             try
             {
                 string sql = "select UserName,Id,Salary from UserInformation where Id = '" + this.txtSalesmanSearch.Text + "' and Role ='Salesman';";
                 this.PopulateGridView(sql);
             }
             catch (Exception exc)
             {
                 MessageBox.Show("An error has occured: " + exc.Message);
             }
        
         }
         private void PopulateGridView(string sql = "select USerName,Id,Salary from UserInformation where Role='Salesman';")
         {
             var ds = this.Da.ExecuteQuery(sql);

             this.dgvUserInfo.AutoGenerateColumns = false;
             this.dgvUserInfo.DataSource = ds.Tables[0];
         }
        

         private void btnClearSearchSalesman_Click(object sender, EventArgs e)
         {
             this.txtSalesmanSearch.Clear();
         }

         private void btnShowInfo_Click(object sender, EventArgs e)
         {
             this.PopulateGridView();
         }


         
     }
}
