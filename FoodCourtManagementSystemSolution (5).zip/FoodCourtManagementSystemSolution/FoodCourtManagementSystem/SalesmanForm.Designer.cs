﻿namespace FoodCourtManagementSystem
{
    partial class SalesmanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbLebonQuantity = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblGenerateBill = new System.Windows.Forms.Label();
            this.lblFoodName = new System.Windows.Forms.Label();
            this.lblFoodPrice = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblLebon = new System.Windows.Forms.Label();
            this.lblLebonPrice = new System.Windows.Forms.Label();
            this.cmbPastaQuantity = new System.Windows.Forms.ComboBox();
            this.cmbIceCreameQuantity = new System.Windows.Forms.ComboBox();
            this.cmbFricesQuantity = new System.Windows.Forms.ComboBox();
            this.cmbBurgerQuantity = new System.Windows.Forms.ComboBox();
            this.cmbChikenQuantity = new System.Windows.Forms.ComboBox();
            this.lblPasta = new System.Windows.Forms.Label();
            this.lblPastaPrice = new System.Windows.Forms.Label();
            this.lblIceCreame = new System.Windows.Forms.Label();
            this.lblIceCreamePrice = new System.Windows.Forms.Label();
            this.lblFrices = new System.Windows.Forms.Label();
            this.lblFricePrice = new System.Windows.Forms.Label();
            this.lblBurger = new System.Windows.Forms.Label();
            this.lblBurgerPrice = new System.Windows.Forms.Label();
            this.lblChikenPot = new System.Windows.Forms.Label();
            this.lblChikenPotPrice = new System.Windows.Forms.Label();
            this.cmbBreadQuantity = new System.Windows.Forms.ComboBox();
            this.lblBread = new System.Windows.Forms.Label();
            this.lblBreadPrice = new System.Windows.Forms.Label();
            this.btnBill = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblBillAmount = new System.Windows.Forms.Label();
            this.lblTotalBill = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.btnFoodSearch = new System.Windows.Forms.Button();
            this.btnShowFoodInfo = new System.Windows.Forms.Button();
            this.btnClearFoodInfo = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lblFoodView = new System.Windows.Forms.Label();
            this.dgvFoodInfo = new System.Windows.Forms.DataGridView();
            this.FoodCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FoodName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnClearSearchSalesman = new System.Windows.Forms.Button();
            this.btnShowInfo = new System.Windows.Forms.Button();
            this.txtSalesmanSearch = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lblSalaryView = new System.Windows.Forms.Label();
            this.lblSearchSalesmanName = new System.Windows.Forms.Label();
            this.btnSearchSalesman = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.dgvUserInfo = new System.Windows.Forms.DataGridView();
            this.SalesmanName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Salary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFoodInfo)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbLebonQuantity
            // 
            this.cmbLebonQuantity.FormattingEnabled = true;
            this.cmbLebonQuantity.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbLebonQuantity.Location = new System.Drawing.Point(428, 126);
            this.cmbLebonQuantity.Name = "cmbLebonQuantity";
            this.cmbLebonQuantity.Size = new System.Drawing.Size(121, 24);
            this.cmbLebonQuantity.TabIndex = 0;
            this.cmbLebonQuantity.Text = "0";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblGenerateBill);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(597, 61);
            this.panel2.TabIndex = 1;
            // 
            // lblGenerateBill
            // 
            this.lblGenerateBill.AutoSize = true;
            this.lblGenerateBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGenerateBill.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblGenerateBill.Location = new System.Drawing.Point(268, 6);
            this.lblGenerateBill.Name = "lblGenerateBill";
            this.lblGenerateBill.Size = new System.Drawing.Size(153, 29);
            this.lblGenerateBill.TabIndex = 0;
            this.lblGenerateBill.Text = "Generate Bill";
            // 
            // lblFoodName
            // 
            this.lblFoodName.AutoSize = true;
            this.lblFoodName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFoodName.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblFoodName.Location = new System.Drawing.Point(29, 73);
            this.lblFoodName.Name = "lblFoodName";
            this.lblFoodName.Size = new System.Drawing.Size(136, 29);
            this.lblFoodName.TabIndex = 1;
            this.lblFoodName.Text = "Food name";
            // 
            // lblFoodPrice
            // 
            this.lblFoodPrice.AutoSize = true;
            this.lblFoodPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFoodPrice.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblFoodPrice.Location = new System.Drawing.Point(231, 73);
            this.lblFoodPrice.Name = "lblFoodPrice";
            this.lblFoodPrice.Size = new System.Drawing.Size(132, 29);
            this.lblFoodPrice.TabIndex = 2;
            this.lblFoodPrice.Text = "Food Price";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblQuantity.Location = new System.Drawing.Point(423, 73);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(100, 29);
            this.lblQuantity.TabIndex = 3;
            this.lblQuantity.Text = "Quantity";
            // 
            // lblLebon
            // 
            this.lblLebon.AutoSize = true;
            this.lblLebon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLebon.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblLebon.Location = new System.Drawing.Point(37, 126);
            this.lblLebon.Name = "lblLebon";
            this.lblLebon.Size = new System.Drawing.Size(55, 20);
            this.lblLebon.TabIndex = 4;
            this.lblLebon.Text = "Lebon";
            // 
            // lblLebonPrice
            // 
            this.lblLebonPrice.AutoSize = true;
            this.lblLebonPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLebonPrice.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblLebonPrice.Location = new System.Drawing.Point(248, 126);
            this.lblLebonPrice.Name = "lblLebonPrice";
            this.lblLebonPrice.Size = new System.Drawing.Size(94, 20);
            this.lblLebonPrice.TabIndex = 5;
            this.lblLebonPrice.Text = "LebonPrice";
            // 
            // cmbPastaQuantity
            // 
            this.cmbPastaQuantity.FormattingEnabled = true;
            this.cmbPastaQuantity.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbPastaQuantity.Location = new System.Drawing.Point(428, 171);
            this.cmbPastaQuantity.Name = "cmbPastaQuantity";
            this.cmbPastaQuantity.Size = new System.Drawing.Size(121, 24);
            this.cmbPastaQuantity.TabIndex = 6;
            this.cmbPastaQuantity.Text = "0";
            // 
            // cmbIceCreameQuantity
            // 
            this.cmbIceCreameQuantity.FormattingEnabled = true;
            this.cmbIceCreameQuantity.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbIceCreameQuantity.Location = new System.Drawing.Point(428, 213);
            this.cmbIceCreameQuantity.Name = "cmbIceCreameQuantity";
            this.cmbIceCreameQuantity.Size = new System.Drawing.Size(121, 24);
            this.cmbIceCreameQuantity.TabIndex = 7;
            this.cmbIceCreameQuantity.Text = "0";
            // 
            // cmbFricesQuantity
            // 
            this.cmbFricesQuantity.FormattingEnabled = true;
            this.cmbFricesQuantity.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbFricesQuantity.Location = new System.Drawing.Point(428, 262);
            this.cmbFricesQuantity.Name = "cmbFricesQuantity";
            this.cmbFricesQuantity.Size = new System.Drawing.Size(121, 24);
            this.cmbFricesQuantity.TabIndex = 8;
            this.cmbFricesQuantity.Text = "0";
            // 
            // cmbBurgerQuantity
            // 
            this.cmbBurgerQuantity.FormattingEnabled = true;
            this.cmbBurgerQuantity.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbBurgerQuantity.Location = new System.Drawing.Point(428, 307);
            this.cmbBurgerQuantity.Name = "cmbBurgerQuantity";
            this.cmbBurgerQuantity.Size = new System.Drawing.Size(121, 24);
            this.cmbBurgerQuantity.TabIndex = 9;
            this.cmbBurgerQuantity.Text = "0";
            // 
            // cmbChikenQuantity
            // 
            this.cmbChikenQuantity.FormattingEnabled = true;
            this.cmbChikenQuantity.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbChikenQuantity.Location = new System.Drawing.Point(428, 349);
            this.cmbChikenQuantity.Name = "cmbChikenQuantity";
            this.cmbChikenQuantity.Size = new System.Drawing.Size(121, 24);
            this.cmbChikenQuantity.TabIndex = 10;
            this.cmbChikenQuantity.Text = "0";
            // 
            // lblPasta
            // 
            this.lblPasta.AutoSize = true;
            this.lblPasta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasta.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblPasta.Location = new System.Drawing.Point(37, 171);
            this.lblPasta.Name = "lblPasta";
            this.lblPasta.Size = new System.Drawing.Size(52, 20);
            this.lblPasta.TabIndex = 11;
            this.lblPasta.Text = "Pasta";
            // 
            // lblPastaPrice
            // 
            this.lblPastaPrice.AutoSize = true;
            this.lblPastaPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPastaPrice.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblPastaPrice.Location = new System.Drawing.Point(248, 171);
            this.lblPastaPrice.Name = "lblPastaPrice";
            this.lblPastaPrice.Size = new System.Drawing.Size(91, 20);
            this.lblPastaPrice.TabIndex = 12;
            this.lblPastaPrice.Text = "PastaPrice";
            // 
            // lblIceCreame
            // 
            this.lblIceCreame.AutoSize = true;
            this.lblIceCreame.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIceCreame.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblIceCreame.Location = new System.Drawing.Point(37, 217);
            this.lblIceCreame.Name = "lblIceCreame";
            this.lblIceCreame.Size = new System.Drawing.Size(95, 20);
            this.lblIceCreame.TabIndex = 13;
            this.lblIceCreame.Text = "Ice Creame";
            // 
            // lblIceCreamePrice
            // 
            this.lblIceCreamePrice.AutoSize = true;
            this.lblIceCreamePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIceCreamePrice.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblIceCreamePrice.Location = new System.Drawing.Point(248, 217);
            this.lblIceCreamePrice.Name = "lblIceCreamePrice";
            this.lblIceCreamePrice.Size = new System.Drawing.Size(129, 20);
            this.lblIceCreamePrice.TabIndex = 14;
            this.lblIceCreamePrice.Text = "IceCreamePrice";
            // 
            // lblFrices
            // 
            this.lblFrices.AutoSize = true;
            this.lblFrices.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFrices.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblFrices.Location = new System.Drawing.Point(37, 262);
            this.lblFrices.Name = "lblFrices";
            this.lblFrices.Size = new System.Drawing.Size(56, 20);
            this.lblFrices.TabIndex = 15;
            this.lblFrices.Text = "Frices";
            // 
            // lblFricePrice
            // 
            this.lblFricePrice.AutoSize = true;
            this.lblFricePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFricePrice.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblFricePrice.Location = new System.Drawing.Point(248, 266);
            this.lblFricePrice.Name = "lblFricePrice";
            this.lblFricePrice.Size = new System.Drawing.Size(95, 20);
            this.lblFricePrice.TabIndex = 16;
            this.lblFricePrice.Text = "FricesPrice";
            // 
            // lblBurger
            // 
            this.lblBurger.AutoSize = true;
            this.lblBurger.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBurger.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblBurger.Location = new System.Drawing.Point(37, 309);
            this.lblBurger.Name = "lblBurger";
            this.lblBurger.Size = new System.Drawing.Size(60, 20);
            this.lblBurger.TabIndex = 17;
            this.lblBurger.Text = "Burger";
            // 
            // lblBurgerPrice
            // 
            this.lblBurgerPrice.AutoSize = true;
            this.lblBurgerPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBurgerPrice.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblBurgerPrice.Location = new System.Drawing.Point(253, 309);
            this.lblBurgerPrice.Name = "lblBurgerPrice";
            this.lblBurgerPrice.Size = new System.Drawing.Size(99, 20);
            this.lblBurgerPrice.TabIndex = 18;
            this.lblBurgerPrice.Text = "BurgerPrice";
            // 
            // lblChikenPot
            // 
            this.lblChikenPot.AutoSize = true;
            this.lblChikenPot.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChikenPot.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblChikenPot.Location = new System.Drawing.Point(37, 354);
            this.lblChikenPot.Name = "lblChikenPot";
            this.lblChikenPot.Size = new System.Drawing.Size(85, 20);
            this.lblChikenPot.TabIndex = 19;
            this.lblChikenPot.Text = "ChikenPot";
            // 
            // lblChikenPotPrice
            // 
            this.lblChikenPotPrice.AutoSize = true;
            this.lblChikenPotPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChikenPotPrice.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblChikenPotPrice.Location = new System.Drawing.Point(253, 349);
            this.lblChikenPotPrice.Name = "lblChikenPotPrice";
            this.lblChikenPotPrice.Size = new System.Drawing.Size(124, 20);
            this.lblChikenPotPrice.TabIndex = 20;
            this.lblChikenPotPrice.Text = "ChikenPotPrice";
            // 
            // cmbBreadQuantity
            // 
            this.cmbBreadQuantity.FormattingEnabled = true;
            this.cmbBreadQuantity.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbBreadQuantity.Location = new System.Drawing.Point(428, 390);
            this.cmbBreadQuantity.Name = "cmbBreadQuantity";
            this.cmbBreadQuantity.Size = new System.Drawing.Size(121, 24);
            this.cmbBreadQuantity.TabIndex = 21;
            this.cmbBreadQuantity.Text = "0";
            // 
            // lblBread
            // 
            this.lblBread.AutoSize = true;
            this.lblBread.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBread.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblBread.Location = new System.Drawing.Point(37, 395);
            this.lblBread.Name = "lblBread";
            this.lblBread.Size = new System.Drawing.Size(54, 20);
            this.lblBread.TabIndex = 22;
            this.lblBread.Text = "Bread";
            // 
            // lblBreadPrice
            // 
            this.lblBreadPrice.AutoSize = true;
            this.lblBreadPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBreadPrice.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblBreadPrice.Location = new System.Drawing.Point(253, 390);
            this.lblBreadPrice.Name = "lblBreadPrice";
            this.lblBreadPrice.Size = new System.Drawing.Size(93, 20);
            this.lblBreadPrice.TabIndex = 23;
            this.lblBreadPrice.Text = "BreadPrice";
            // 
            // btnBill
            // 
            this.btnBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBill.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnBill.Location = new System.Drawing.Point(24, 468);
            this.btnBill.Name = "btnBill";
            this.btnBill.Size = new System.Drawing.Size(108, 52);
            this.btnBill.TabIndex = 24;
            this.btnBill.Text = "Bill";
            this.btnBill.UseVisualStyleBackColor = true;
            this.btnBill.Click += new System.EventHandler(this.btnBill_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.lblBillAmount);
            this.panel1.Controls.Add(this.lblTotalBill);
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.btnBill);
            this.panel1.Controls.Add(this.lblBreadPrice);
            this.panel1.Controls.Add(this.lblBread);
            this.panel1.Controls.Add(this.cmbBreadQuantity);
            this.panel1.Controls.Add(this.lblChikenPotPrice);
            this.panel1.Controls.Add(this.lblChikenPot);
            this.panel1.Controls.Add(this.lblBurgerPrice);
            this.panel1.Controls.Add(this.lblBurger);
            this.panel1.Controls.Add(this.lblFricePrice);
            this.panel1.Controls.Add(this.lblFrices);
            this.panel1.Controls.Add(this.lblIceCreamePrice);
            this.panel1.Controls.Add(this.lblIceCreame);
            this.panel1.Controls.Add(this.lblPastaPrice);
            this.panel1.Controls.Add(this.lblPasta);
            this.panel1.Controls.Add(this.cmbChikenQuantity);
            this.panel1.Controls.Add(this.cmbBurgerQuantity);
            this.panel1.Controls.Add(this.cmbFricesQuantity);
            this.panel1.Controls.Add(this.cmbIceCreameQuantity);
            this.panel1.Controls.Add(this.cmbPastaQuantity);
            this.panel1.Controls.Add(this.lblLebonPrice);
            this.panel1.Controls.Add(this.lblLebon);
            this.panel1.Controls.Add(this.lblQuantity);
            this.panel1.Controls.Add(this.lblFoodPrice);
            this.panel1.Controls.Add(this.lblFoodName);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.cmbLebonQuantity);
            this.panel1.Location = new System.Drawing.Point(946, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(597, 616);
            this.panel1.TabIndex = 0;
            // 
            // lblBillAmount
            // 
            this.lblBillAmount.AutoSize = true;
            this.lblBillAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillAmount.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblBillAmount.Location = new System.Drawing.Point(190, 567);
            this.lblBillAmount.Name = "lblBillAmount";
            this.lblBillAmount.Size = new System.Drawing.Size(0, 29);
            this.lblBillAmount.TabIndex = 27;
            // 
            // lblTotalBill
            // 
            this.lblTotalBill.AutoSize = true;
            this.lblTotalBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalBill.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblTotalBill.Location = new System.Drawing.Point(31, 567);
            this.lblTotalBill.Name = "lblTotalBill";
            this.lblTotalBill.Size = new System.Drawing.Size(139, 29);
            this.lblTotalBill.TabIndex = 26;
            this.lblTotalBill.Text = "Total Bill : ";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnClear.Location = new System.Drawing.Point(195, 468);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(108, 52);
            this.btnClear.TabIndex = 25;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.txtSearch);
            this.panel5.Controls.Add(this.lblSearch);
            this.panel5.Controls.Add(this.btnFoodSearch);
            this.panel5.Controls.Add(this.btnShowFoodInfo);
            this.panel5.Controls.Add(this.btnClearFoodInfo);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Location = new System.Drawing.Point(0, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(360, 390);
            this.panel5.TabIndex = 28;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(136, 130);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(110, 22);
            this.txtSearch.TabIndex = 38;
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblSearch.Location = new System.Drawing.Point(20, 130);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(110, 18);
            this.lblSearch.TabIndex = 37;
            this.lblSearch.Text = "Search Food:";
            // 
            // btnFoodSearch
            // 
            this.btnFoodSearch.Location = new System.Drawing.Point(23, 169);
            this.btnFoodSearch.Name = "btnFoodSearch";
            this.btnFoodSearch.Size = new System.Drawing.Size(93, 39);
            this.btnFoodSearch.TabIndex = 36;
            this.btnFoodSearch.Text = "Search";
            this.btnFoodSearch.UseVisualStyleBackColor = true;
            this.btnFoodSearch.Click += new System.EventHandler(this.btnFoodSearch_Click);
            // 
            // btnShowFoodInfo
            // 
            this.btnShowFoodInfo.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.btnShowFoodInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowFoodInfo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnShowFoodInfo.Location = new System.Drawing.Point(223, 328);
            this.btnShowFoodInfo.Name = "btnShowFoodInfo";
            this.btnShowFoodInfo.Size = new System.Drawing.Size(135, 43);
            this.btnShowFoodInfo.TabIndex = 31;
            this.btnShowFoodInfo.Text = "Show Info>>>";
            this.btnShowFoodInfo.UseVisualStyleBackColor = false;
            this.btnShowFoodInfo.Click += new System.EventHandler(this.btnShowFoodInfo_Click);
            // 
            // btnClearFoodInfo
            // 
            this.btnClearFoodInfo.Location = new System.Drawing.Point(23, 332);
            this.btnClearFoodInfo.Name = "btnClearFoodInfo";
            this.btnClearFoodInfo.Size = new System.Drawing.Size(93, 39);
            this.btnClearFoodInfo.TabIndex = 31;
            this.btnClearFoodInfo.Text = "Clear";
            this.btnClearFoodInfo.UseVisualStyleBackColor = true;
            this.btnClearFoodInfo.Click += new System.EventHandler(this.btnClearFoodInfo_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.lblFoodView);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(356, 58);
            this.panel7.TabIndex = 0;
            // 
            // lblFoodView
            // 
            this.lblFoodView.AutoSize = true;
            this.lblFoodView.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFoodView.ForeColor = System.Drawing.Color.SteelBlue;
            this.lblFoodView.Location = new System.Drawing.Point(78, 4);
            this.lblFoodView.Name = "lblFoodView";
            this.lblFoodView.Size = new System.Drawing.Size(129, 29);
            this.lblFoodView.TabIndex = 0;
            this.lblFoodView.Text = "Food View";
            // 
            // dgvFoodInfo
            // 
            this.dgvFoodInfo.AllowUserToAddRows = false;
            this.dgvFoodInfo.AllowUserToDeleteRows = false;
            this.dgvFoodInfo.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvFoodInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFoodInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FoodCode,
            this.FoodName,
            this.Price});
            this.dgvFoodInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvFoodInfo.Location = new System.Drawing.Point(0, 0);
            this.dgvFoodInfo.Name = "dgvFoodInfo";
            this.dgvFoodInfo.ReadOnly = true;
            this.dgvFoodInfo.RowTemplate.Height = 24;
            this.dgvFoodInfo.Size = new System.Drawing.Size(360, 221);
            this.dgvFoodInfo.TabIndex = 29;
            // 
            // FoodCode
            // 
            this.FoodCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FoodCode.DataPropertyName = "FoodCode";
            this.FoodCode.HeaderText = "Food code";
            this.FoodCode.Name = "FoodCode";
            this.FoodCode.ReadOnly = true;
            // 
            // FoodName
            // 
            this.FoodName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FoodName.DataPropertyName = "FoodName";
            this.FoodName.HeaderText = "Food Name";
            this.FoodName.Name = "FoodName";
            this.FoodName.ReadOnly = true;
            // 
            // Price
            // 
            this.Price.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Price.DataPropertyName = "Price";
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dgvFoodInfo);
            this.panel3.Location = new System.Drawing.Point(0, 398);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(360, 221);
            this.panel3.TabIndex = 30;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnLogOut);
            this.panel4.Location = new System.Drawing.Point(1394, 625);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(149, 68);
            this.panel4.TabIndex = 31;
            // 
            // btnLogOut
            // 
            this.btnLogOut.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnLogOut.Location = new System.Drawing.Point(0, 0);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(149, 68);
            this.btnLogOut.TabIndex = 0;
            this.btnLogOut.Text = "LogOut";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.btnClearSearchSalesman);
            this.panel6.Controls.Add(this.btnShowInfo);
            this.panel6.Controls.Add(this.txtSalesmanSearch);
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.lblSearchSalesmanName);
            this.panel6.Controls.Add(this.btnSearchSalesman);
            this.panel6.Location = new System.Drawing.Point(355, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(596, 390);
            this.panel6.TabIndex = 32;
            // 
            // btnClearSearchSalesman
            // 
            this.btnClearSearchSalesman.Location = new System.Drawing.Point(77, 346);
            this.btnClearSearchSalesman.Name = "btnClearSearchSalesman";
            this.btnClearSearchSalesman.Size = new System.Drawing.Size(93, 39);
            this.btnClearSearchSalesman.TabIndex = 39;
            this.btnClearSearchSalesman.Text = "Clear";
            this.btnClearSearchSalesman.UseVisualStyleBackColor = true;
            this.btnClearSearchSalesman.Click += new System.EventHandler(this.btnClearSearchSalesman_Click);
            // 
            // btnShowInfo
            // 
            this.btnShowInfo.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.btnShowInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowInfo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnShowInfo.Location = new System.Drawing.Point(450, 347);
            this.btnShowInfo.Name = "btnShowInfo";
            this.btnShowInfo.Size = new System.Drawing.Size(135, 43);
            this.btnShowInfo.TabIndex = 39;
            this.btnShowInfo.Text = "Show Info>>>";
            this.btnShowInfo.UseVisualStyleBackColor = false;
            this.btnShowInfo.Click += new System.EventHandler(this.btnShowInfo_Click);
            // 
            // txtSalesmanSearch
            // 
            this.txtSalesmanSearch.Location = new System.Drawing.Point(236, 126);
            this.txtSalesmanSearch.Name = "txtSalesmanSearch";
            this.txtSalesmanSearch.Size = new System.Drawing.Size(110, 22);
            this.txtSalesmanSearch.TabIndex = 41;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.lblSalaryView);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(596, 61);
            this.panel8.TabIndex = 0;
            // 
            // lblSalaryView
            // 
            this.lblSalaryView.AutoSize = true;
            this.lblSalaryView.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalaryView.ForeColor = System.Drawing.Color.SteelBlue;
            this.lblSalaryView.Location = new System.Drawing.Point(226, 6);
            this.lblSalaryView.Name = "lblSalaryView";
            this.lblSalaryView.Size = new System.Drawing.Size(139, 29);
            this.lblSalaryView.TabIndex = 1;
            this.lblSalaryView.Text = "Salary View";
            // 
            // lblSearchSalesmanName
            // 
            this.lblSearchSalesmanName.AutoSize = true;
            this.lblSearchSalesmanName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchSalesmanName.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblSearchSalesmanName.Location = new System.Drawing.Point(85, 128);
            this.lblSearchSalesmanName.Name = "lblSearchSalesmanName";
            this.lblSearchSalesmanName.Size = new System.Drawing.Size(145, 18);
            this.lblSearchSalesmanName.TabIndex = 40;
            this.lblSearchSalesmanName.Text = "Search Salesman:";
            // 
            // btnSearchSalesman
            // 
            this.btnSearchSalesman.Location = new System.Drawing.Point(88, 171);
            this.btnSearchSalesman.Name = "btnSearchSalesman";
            this.btnSearchSalesman.Size = new System.Drawing.Size(93, 39);
            this.btnSearchSalesman.TabIndex = 39;
            this.btnSearchSalesman.Text = "Search";
            this.btnSearchSalesman.UseVisualStyleBackColor = true;
            this.btnSearchSalesman.Click += new System.EventHandler(this.btnSearchSalesman_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel9.Controls.Add(this.dgvUserInfo);
            this.panel9.Location = new System.Drawing.Point(366, 399);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(585, 217);
            this.panel9.TabIndex = 42;
            // 
            // dgvUserInfo
            // 
            this.dgvUserInfo.AllowUserToAddRows = false;
            this.dgvUserInfo.AllowUserToDeleteRows = false;
            this.dgvUserInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUserInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SalesmanName,
            this.Id,
            this.Salary});
            this.dgvUserInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvUserInfo.Location = new System.Drawing.Point(0, 0);
            this.dgvUserInfo.Name = "dgvUserInfo";
            this.dgvUserInfo.ReadOnly = true;
            this.dgvUserInfo.RowTemplate.Height = 24;
            this.dgvUserInfo.Size = new System.Drawing.Size(585, 217);
            this.dgvUserInfo.TabIndex = 0;
            // 
            // SalesmanName
            // 
            this.SalesmanName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SalesmanName.DataPropertyName = "UserName";
            this.SalesmanName.HeaderText = "Salesman Name";
            this.SalesmanName.Name = "SalesmanName";
            this.SalesmanName.ReadOnly = true;
            // 
            // Id
            // 
            this.Id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Id.DataPropertyName = "Id";
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            // 
            // Salary
            // 
            this.Salary.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Salary.DataPropertyName = "Salary";
            this.Salary.HeaderText = "Salary";
            this.Salary.Name = "Salary";
            this.Salary.ReadOnly = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(364, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 18);
            this.label1.TabIndex = 42;
            this.label1.Text = "(Search by Salesman ID)";
            // 
            // SalesmanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1545, 705);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Name = "SalesmanForm";
            this.Text = "SalesmanForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SalesmanForm_FormClosed);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFoodInfo)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserInfo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbLebonQuantity;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblGenerateBill;
        private System.Windows.Forms.Label lblFoodName;
        private System.Windows.Forms.Label lblFoodPrice;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblLebon;
        private System.Windows.Forms.Label lblLebonPrice;
        private System.Windows.Forms.ComboBox cmbPastaQuantity;
        private System.Windows.Forms.ComboBox cmbIceCreameQuantity;
        private System.Windows.Forms.ComboBox cmbFricesQuantity;
        private System.Windows.Forms.ComboBox cmbBurgerQuantity;
        private System.Windows.Forms.ComboBox cmbChikenQuantity;
        private System.Windows.Forms.Label lblPasta;
        private System.Windows.Forms.Label lblPastaPrice;
        private System.Windows.Forms.Label lblIceCreame;
        private System.Windows.Forms.Label lblIceCreamePrice;
        private System.Windows.Forms.Label lblFrices;
        private System.Windows.Forms.Label lblFricePrice;
        private System.Windows.Forms.Label lblBurger;
        private System.Windows.Forms.Label lblBurgerPrice;
        private System.Windows.Forms.Label lblChikenPot;
        private System.Windows.Forms.Label lblChikenPotPrice;
        private System.Windows.Forms.ComboBox cmbBreadQuantity;
        private System.Windows.Forms.Label lblBread;
        private System.Windows.Forms.Label lblBreadPrice;
        private System.Windows.Forms.Button btnBill;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblBillAmount;
        private System.Windows.Forms.Label lblTotalBill;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.Button btnFoodSearch;
        private System.Windows.Forms.Button btnShowFoodInfo;
        private System.Windows.Forms.Button btnClearFoodInfo;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lblFoodView;
        private System.Windows.Forms.DataGridView dgvFoodInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn FoodCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn FoodName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txtSalesmanSearch;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lblSalaryView;
        private System.Windows.Forms.Label lblSearchSalesmanName;
        private System.Windows.Forms.Button btnSearchSalesman;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.DataGridView dgvUserInfo;
        private System.Windows.Forms.Button btnClearSearchSalesman;
        private System.Windows.Forms.Button btnShowInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn SalesmanName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Salary;
        private System.Windows.Forms.Label label1;

    }
}